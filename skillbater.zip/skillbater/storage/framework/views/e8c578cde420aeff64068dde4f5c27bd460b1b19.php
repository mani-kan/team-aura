<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Skill-Barter Network</title>

<style>
body{
margin:0;
font-family:system-ui;
background:linear-gradient(135deg,#eef2f7,#dde3ea);
}

.hero{
text-align:center;
padding:100px 20px;
}

.hero h1{
font-size:48px;
color:#2563eb;
}

.hero p{
font-size:20px;
color:#444;
max-width:600px;
margin:auto;
}

.btn{
background:#2563eb;
color:white;
padding:14px 28px;
border-radius:30px;
text-decoration:none;
font-size:18px;
display:inline-block;
margin-top:30px;
}

.section{
padding:70px 20px;
text-align:center;
}

.features{
display:flex;
justify-content:center;
gap:30px;
flex-wrap:wrap;
}

.card{
background:white;
padding:25px;
border-radius:18px;
width:260px;
box-shadow:0 10px 25px rgba(0,0,0,.1);
}

.steps{
display:flex;
justify-content:center;
gap:30px;
flex-wrap:wrap;
}

.footer{
text-align:center;
padding:30px;
color:#666;
}
</style>
</head>

<body>

<!-- HERO -->
<div class="hero">
<h1>Skill-Barter Network</h1>
<p>Learn new skills by exchanging what you already know.  
Connect, chat, collaborate and grow together — without money.</p>

<a href="/login" class="btn">Get Started</a>
</div>

<!-- FEATURES -->
<div class="section">
<h2>What You Can Do</h2>

<div class="features">

<div class="card">
<h3>🎓 Learn Skills</h3>
<p>Find people who teach what you want to learn.</p>
</div>

<div class="card">
<h3>🤝 Exchange Knowledge</h3>
<p>Teach what you know and learn in return.</p>
</div>

<div class="card">
<h3>💬 Chat & Connect</h3>
<p>Message users and plan learning sessions.</p>
</div>

<div class="card">
<h3>⭐ Build Profile</h3>
<p>Earn ratings and grow your reputation.</p>
</div>

</div>
</div>

<!-- HOW IT WORKS -->
<div class="section">
<h2>How It Works</h2>

<div class="steps">

<div class="card">
<h3>1️⃣ Add Skills</h3>
<p>Tell what you know and what you want to learn.</p>
</div>

<div class="card">
<h3>2️⃣ Send Requests</h3>
<p>Connect with matching users.</p>
</div>

<div class="card">
<h3>3️⃣ Learn Together</h3>
<p>Chat, share knowledge and grow.</p>
</div>

</div>
</div>

<!-- FOOTER -->
<div class="footer">
© 2026 Skill-Barter Network — Learn Together
</div>

</body>
</html>
<?php /**PATH C:\Team Aura\skillbater\resources\views/index.blade.php ENDPATH**/ ?>